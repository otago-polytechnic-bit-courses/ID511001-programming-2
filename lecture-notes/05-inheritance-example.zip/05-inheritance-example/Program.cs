﻿using System;

namespace _05_inheritance_example
{
    public class Program
    {
        static void Main(string[] args)
        {
            Animal animal = new Animal("Teddy", 10);
            Dog dog = new Dog("Fido", 15, "Brown");

            animal.Eat();
            dog.Eat();

            animal.Sleep();
            dog.Sleep();

            dog.Bark();
        }
    }
}
